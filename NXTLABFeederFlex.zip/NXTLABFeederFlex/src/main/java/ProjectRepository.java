package main.java;

import com.github.daniel.shuy.ws.rs.jpa.crud.RepositoryCRUD;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ProjectRepository implements RepositoryCRUD<main.java.ProjectRecord> {
    // argument is Persistence Unit Name configured in persistence.xml
    private static final EntityManagerFactory factory = Persistence.createEntityManagerFactory("persistence-unit");

    private final EntityManager entityManager;

    public ProjectRepository() {
        entityManager = factory.createEntityManager();
    }

    @Override
    public EntityManager getEntityManager() {
        return entityManager;
    }

    @Override
    public Class<main.java.ProjectRecord> getEntityClass() {
        return main.java.ProjectRecord.class;
    }
}