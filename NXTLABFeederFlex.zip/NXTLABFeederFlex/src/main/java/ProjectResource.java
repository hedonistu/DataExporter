import com.github.daniel.shuy.ws.rs.jpa.crud.RepositoryCRUD;
import com.github.daniel.shuy.ws.rs.jpa.crud.ResourceCRUD;

import javax.ws.rs.Path;

@Path("/project")
public class ProjectResource extends ResourceCRUD<main.java.ProjectRecord> {
    @Override
    public RepositoryCRUD<main.java.ProjectRecord> getRepository() {
        return new main.java.ProjectRepository();
    }
}